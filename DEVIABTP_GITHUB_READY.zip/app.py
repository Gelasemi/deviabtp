
import streamlit as st
import pandas as pd
import plotly.express as px
from fpdf import FPDF
from datetime import datetime
import os

st.set_page_config(page_title="DEVIABTP - Mialy&G", layout="wide")

# Logo et titre
st.image("Mialy&G.png", width=120)
st.title("DEVIABTP - Mialy&G")

# Base utilisateur simple
if "auth" not in st.session_state:
    st.session_state.auth = False
    st.session_state.username = ""

def login():
    with st.sidebar:
        st.subheader("🔐 Connexion utilisateur")
        user = st.text_input("Nom d'utilisateur")
        password = st.text_input("Mot de passe", type="password")
        if st.button("Se connecter"):
            if user == "admin" and password == "admin":
                st.session_state.auth = True
                st.session_state.username = user
            else:
                st.error("Identifiants invalides")

# Pages
menu = st.sidebar.radio("Navigation", ["Accueil", "Créer un devis", "Historique", "Connexion"])

# Sélecteur de langue
langue = st.sidebar.selectbox("Langue", ["Français", "English", "Malagasy"])

# Données simulées
@st.cache_data
def load_data():
    return pd.DataFrame([
        {"Client": "Ando", "Projet": "Maison", "Paramètre": "2 étages", "Coût (Ar)": 125_000_000, "Date": "2025-07-15"},
        {"Client": "Rasoa", "Projet": "Route", "Paramètre": "1 km", "Coût (Ar)": 1_450_000_000, "Date": "2025-07-16"},
        {"Client": "Jean", "Projet": "Pont Béton", "Paramètre": "30 m", "Coût (Ar)": 2_800_000_000, "Date": "2025-07-17"},
        {"Client": "Lova", "Projet": "Maison", "Paramètre": "1 étage", "Coût (Ar)": 95_000_000, "Date": "2025-07-18"},
        {"Client": "Koto", "Projet": "Pont Métallique", "Paramètre": "40 m", "Coût (Ar)": 2_300_000_000, "Date": "2025-07-19"},
    ])

if menu == "Accueil":
    st.subheader("Bienvenue sur DEVIABTP")
    st.write("Un assistant intelligent pour générer des devis BTP complets (maison, pont, route).")
    st.success("Choisissez une action dans le menu de gauche.")

elif menu == "Connexion":
    login()
    if st.session_state.auth:
        st.success(f"Connecté en tant que {st.session_state.username}")

elif menu == "Créer un devis":
    st.subheader("🧾 Création de devis")
    client = st.text_input("Nom du client")
    projet = st.selectbox("Type de projet", ["Maison", "Route", "Pont Béton", "Pont Métallique"])
    param = st.text_input("Paramètre (étage, km ou m)")
    cout = st.number_input("Coût estimé (Ar)", step=100000)
    if st.button("Générer le PDF"):
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", 'B', 14)
        pdf.cell(0, 10, "DEVIABTP - Mialy&G", ln=1, align='C')
        pdf.set_font("Arial", '', 12)
        pdf.ln(10)
        pdf.cell(0, 10, f"Client : {client}", ln=1)
        pdf.cell(0, 10, f"Projet : {projet}", ln=1)
        pdf.cell(0, 10, f"Paramètre : {param}", ln=1)
        pdf.cell(0, 10, f"Coût estimé : {int(cout):,} Ariary", ln=1)
        filename = f"devis_{client}_{datetime.now().strftime('%Y%m%d%H%M%S')}.pdf"
        pdf.output(filename)
        st.success("PDF généré avec succès.")
        with open(filename, "rb") as f:
            st.download_button("📥 Télécharger le PDF", f, file_name=filename, mime="application/pdf")

elif menu == "Historique":
    st.subheader("📊 Projets enregistrés")
    df = load_data()
    st.dataframe(df)
    chart = px.bar(df, x="Client", y="Coût (Ar)", color="Projet", title="Coût estimé par client")
    st.plotly_chart(chart, use_container_width=True)
