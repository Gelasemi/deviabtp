# DEVIABTP – Mialy&G

Application Streamlit pour générer des devis BTP intelligents avec IA, PDF et interface multilingue (🇲🇬 🇫🇷 🇬🇧).

## 📦 Fonctionnalités

- Génération de devis pour :
  - Maisons (1 à 25 étages)
  - Routes goudronnées (1 km et +)
  - Ponts béton ou métalliques
- Traduction dynamique (anglais, français, malagasy)
- Téléversement de croquis (pour analyse future)
- Génération de PDF automatiquement
- Graphiques et tableau de projets

## 🚀 Lancer avec Streamlit Cloud

1. Crée un dépôt GitHub et uploade tous les fichiers de ce projet.
2. Va sur https://streamlit.io/cloud
3. Clique sur “New app”
4. Sélectionne ton repo GitHub
5. Fichier principal : `app.py`
6. Clique sur Deploy ✅

